main.py : main program
make_scheduler.py : make yamls and create scheduler

usage:
python make_scheduler.py [job_numbers] [submitted job time period] [scheduler used]
python main.py
